const modal = document.querySelector(".info-modal");
const modalCloseBtn = document.querySelector(".close-btn");
const modalContent = document.querySelector(".modal-content");
const dynamicContent = document.querySelector(".dynamic-content");


modalCloseBtn.addEventListener('click', () => {
    modal.style.display = "none"
})

function getUsersandPhotos() {
    Promise.all([
        axios.get("https://jsonplaceholder.typicode.com/users"),
        axios.get("https://api.unsplash.com/search/photos?query=person", {headers: {Authorization: "Client-ID"}})
    ]).then(data => agrigateData(data))
}

function agrigateData(dataList){
    const newUserList = dataList[0].data.map((user, index) => {
        return {...user, imageUrl: dataList[1].data.results[index].urls.full}
    });
    renderUserCards(newUserList)
}

function renderUserCards(userList) {
    const userBox = document.querySelector('.users-box');
    console.log(userList);
    userList.map(user => {
        const userHTML = `
            <div class="user" id="user-${user.id}">
                <img src="${user.imageUrl+"&w=150&h=150&fit=crop&crop=faces"}" alt="${user.id}">
                <div class="naming-info">
                    <p class="name">${user.name.split(" ")[0]}</p>
                    <p class="mail">${user.email}</p>
                </div>
            </div>
        `;
        userBox.insertAdjacentHTML("beforeend", userHTML);
        console.log(document.querySelector(`#user-${user.id}`));
        document.querySelector(`#user-${user.id}`).addEventListener("click", () => {
            dynamicContent.innerHTML = "";
            const content = `
                <div class="content">
                    <div class="personal-info">
                        <h3>Personal Info</h3>
                        <div>
                            <p class="label">Name:</p>
                            <p>${user.name}</p>
                        </div>
                        <div>
                            <p class="label">Contacts:</p>
                            <p>${user.phone}</p>
                            <p>https://www.${user.website}</p>
                            <p>${user.email}</p>
                        </div>
                    </div>
                    <div class="address-info">
                        <h3>Address Info</h3>
                        <p class="label">Main Address:</p>
                        <p>${user.address.city + " " + user.address.street + " " + user.address.suite}</p>
                        <p>GEO: ${user.address.geo.lat} / ${user.address.geo.lng}</p>
                    </div>
                    <div class="company-info">
                        <h3>Company Info</h3>
                        <p class="label">Company name:</p>
                        <p>${user.company.name}</p>
                        <p>Company Description:</p>
                        <p>${user.company.bs}</p>
                    </div>
                </div>
            `
            console.log(modalContent);
            dynamicContent.insertAdjacentHTML("afterbegin", content);
            modal.style.display = "block";
        });
    })
}

getUsersandPhotos();